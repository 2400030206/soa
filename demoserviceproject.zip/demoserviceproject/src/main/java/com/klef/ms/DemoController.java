package com.klef.ms;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jakarta.websocket.server.PathParam;

@RestController

public class DemoController {
	List<Employee>emplist=new ArrayList<Employee>();
@GetMapping("/")
public String home() {
	return "demo service project";
}
@PostMapping("/addemp")
public ResponseEntity<String> addemployee(@RequestBody Employee emp) {
	emplist.add(emp);
	return ResponseEntity.status(201).body("Employee add successful");
}
@GetMapping("displayallemps")
public ResponseEntity<?> displayall() {
	if(emplist.size()>0) {
	return ResponseEntity.ok(emplist);
	}
	else {
		return ResponseEntity.status(204).body("employee data not found");
	}
}
@GetMapping("/empcount")
public int empcount() {
	return emplist.size();
}
@GetMapping("add")//localhost:2027/add?a=10&b=20
public String add(@RequestParam int a ,@RequestParam int b) {
	return "Output="+(a+b);
}
@GetMapping("sum/{a}/{b}")
public String sum(@PathVariable int a,@PathVariable int b) {
	return "Output"+(a+b);
}
@GetMapping("demo/{fname}/{lname}")
	public String demo(@PathVariable String fname, @PathVariable String lname) {
		return fname+" "+lname;
	}
}


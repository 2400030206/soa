package com.klef.ms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoserviceprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoserviceprojectApplication.class, args);
		System.out.print("Demo project project is running.......!!!");
	}
}
